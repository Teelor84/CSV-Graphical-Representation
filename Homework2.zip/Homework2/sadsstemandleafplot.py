import matplotlib.pyplot as plt
import pandas as pd
import stemgraphic

data = pd.read_csv(r'C:\Users\tp887\PycharmProjects\Homework2\Dataset.csv', sep=',')

data1 = data['num_sads']
y = pd.Series(data1)
figure, axis = stemgraphic.stem_graphic(y)

plt.show()
