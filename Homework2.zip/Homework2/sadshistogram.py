import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

data = pd.read_csv(r'C:\Users\tp887\PycharmProjects\Homework2\Dataset.csv', sep=',')
sns.distplot(data['num_sads'])

plt.title("Histogram of Sads")
plt.xlabel("Number of Sads")
plt.ylabel("Frequency")
plt.show()