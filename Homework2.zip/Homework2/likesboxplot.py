import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_csv(r'C:\Users\tp887\Desktop\Dataset.csv', sep=',')
plt.boxplot(data['num_likes'])

plt.ylabel("Number of Likes")
plt.title("Box Plot for the Number of Likes")
plt.show()