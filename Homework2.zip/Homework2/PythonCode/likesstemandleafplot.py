import matplotlib.pyplot as plt
import pandas as pd
import stemgraphic

data = pd.read_csv(r'C:\Users\tp887\Desktop\Dataset.csv', sep=',')

data1 = data['num_likes']
y = pd.Series(data1)

figure, axis = stemgraphic.stem_graphic(y)


plt.show()



