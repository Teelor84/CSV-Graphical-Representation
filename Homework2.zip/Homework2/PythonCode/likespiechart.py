import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
data = pd.read_csv(r'C:\Users\tp887\Desktop\Dataset.csv', sep=',')

data1 = data['num_likes']

bins1 = [0, 1000, 2000, 3000, 4000, 5000]
labels1 = ["0-1000", "1000-2000", "2000-3000", "3000-4000", "4000-5000"]
data['bins'] = pd.cut(data['num_likes'], bins = bins1, labels = labels1)
grouping = data.groupby('bins').size()
plt.pie(grouping, labels=labels1)

plt.show()




