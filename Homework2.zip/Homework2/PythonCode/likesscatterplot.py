import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

data = pd.read_csv(r'C:\Users\tp887\Desktop\Dataset.csv', sep=',')

x = data['num_likes']
y = data['num_loves']

a, b = np.polyfit(x, y, 1)
plt.scatter(x, y)
plt.plot(x, a*x+b)
plt.xlabel("Likes")
plt.ylabel("Loves")

plt.show()


