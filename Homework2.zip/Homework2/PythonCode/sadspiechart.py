import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
data = pd.read_csv(r'C:\Users\tp887\Desktop\Dataset.csv', sep=',')

data1 = data['num_sads']

bins1 = [0, 10, 20, 30, 40, 50]
labels1 = ["0-10", "10-20", "20-30", "30-40", "40-50"]
data['bins'] = pd.cut(data['num_sads'], bins = bins1, labels = labels1)
grouping = data.groupby('bins').size()
plt.pie(grouping, labels=labels1)

plt.show()