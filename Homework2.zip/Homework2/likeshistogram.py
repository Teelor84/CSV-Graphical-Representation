import matplotlib.pyplot as p
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

data = pd.read_csv(r'C:\Users\tp887\PycharmProjects\Homework2\Dataset.csv', sep=',')
sns.distplot(data['num_likes'])
plt.title("Histogram of Likes")
plt.xlabel("Number of Likes")
plt.ylabel("Frequency")
plt.show()











