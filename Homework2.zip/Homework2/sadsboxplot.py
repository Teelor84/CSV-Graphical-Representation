import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_csv(r'C:\Users\tp887\PycharmProjects\Homework2\Dataset.csv', sep=',')
plt.boxplot(data['num_sads'])

plt.ylabel("Number of Sads")
plt.title("Box Plot for the Number of Sads")
plt.show()