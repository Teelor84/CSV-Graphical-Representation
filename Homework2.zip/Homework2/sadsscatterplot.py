import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

data = pd.read_csv(r'C:\Users\tp887\PycharmProjects\Homework2\Dataset.csv', sep=',')

x = data['num_sads']
y = data['num_loves']

a, b = np.polyfit(x, y, 1)
plt.scatter(x, y)
plt.plot(x, a*x+b)
plt.xlabel("Sads")
plt.ylabel("Loves")

plt.show()
