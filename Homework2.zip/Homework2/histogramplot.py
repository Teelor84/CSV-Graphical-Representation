import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

dataframe = pd.read_csv(r'C:\Users\tp887\Downloads\Dataset.csv', sep=',')

#C
column1 = dataframe['AH']
#E
column2 = dataframe['GTEP']
#G
column3 = dataframe['TAT']
#H
column4 = dataframe['TEY']
#K
column5 = dataframe['NOX']

sns.distplot(dataframe['AH'])
plt.title("Histogram of AH")
plt.xlabel("Number of specific values in AH")
plt.ylabel("Frequency")
plt.show()

sns.distplot(dataframe['GTEP'])
plt.title("Histogram of GTEP")
plt.xlabel("Number of specific values in GTEP")
plt.ylabel("Frequency")
plt.show()

sns.distplot(dataframe['TAT'])
plt.title("Histogram of TAT")
plt.xlabel("Number of specific values in TAT")
plt.ylabel("Frequency")
plt.show()

sns.distplot(dataframe['TEY'])
plt.title("Histogram of TEY")
plt.xlabel("Number of specific values in TEY")
plt.ylabel("Frequency")
plt.show()

sns.distplot(dataframe['NOX'])
plt.title("Histogram of NOX")
plt.xlabel("Number of specific values in NOX")
plt.ylabel("Frequency")
plt.show()